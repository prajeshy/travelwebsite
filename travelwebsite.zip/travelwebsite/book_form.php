<?php


   $connection = mysqli_connect('localhost','root','','book_db');

   if(isset($_POST['send'])){
      $name = $_POST['name'];
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $address = $_POST['address'];
      $location = $_POST['location'];
      $guests = $_POST['guests'];
      $arrivals = $_POST['arrivals'];
      $leaving = $_POST['leaving'];

      $request = " insert into book_form(name, email, phone, address, location, guests, arrivals, leaving) values('$name','$email','$phone','$address','$location','$guests','$arrivals','$leaving') ";
      mysqli_query($connection, $request);
      if($location == 'msk')
      {
         header("Location: https://rzp.io/l/gQppcAXwxd");
      }
      else if($location == 'ml')
      {
         header("Location: https://rzp.io/l/lBXahaU5b9");
      }
      else if($location == 'goa')
      {
         header("Location: https://rzp.io/l/LLOXBwXhM");
      }
      else if($location == 'ladakh')
      {
         header("Location: https://rzp.io/l/jlUJEF4");
      }
      else if($location == 'spiti')
      {
         header("Location: https://rzp.io/l/ffUp4GZtM");
      }
      else if($location == 'nth')
      {
         header("Location: https://rzp.io/l/hK6Fy6v");
      }
      else if($location == 'mclod')
      {
         header("Location: https://rzp.io/l/Qn7Rgs9");
      }
      else if($location == 'chopta')
      {
         header("Location: https://rzp.io/l/PN5q1p00Q2");
      }
      else if($location == 'tirthan')
      {
         header("Location: https://rzp.io/l/Av38k1tTJu");
      }
      
   }else{
      echo 'something went wrong please try again!';
   }

?>
